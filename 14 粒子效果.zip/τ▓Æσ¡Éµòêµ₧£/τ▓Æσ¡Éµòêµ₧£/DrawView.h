//
//  DrawView.h
//  粒子效果
//
//  Created by 蓝田 on 16/7/24.
//  Copyright © 2016年 Loto. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DrawView : UIView
- (void)startAnim; // 开始动画
- (void)reDraw;    // 重绘
@end