//
//  AppDelegate.h
//  旋转立体效果
//
//  Created by 蓝田 on 16/7/21.
//  Copyright © 2016年 Loto. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

